📦 TermKit Installer

1. Open TermKit.dmg
2. Right-click on setup.command → choose "Open"
3. Enter your password if prompted
4. Run TermKit from the terminal using: tk or termkit

Requirements:
- macOS with Python 3 installed
- Internet connection for first-time dependency installation
